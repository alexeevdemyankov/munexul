<?php
/*
Plugin Name: Munexul domain Plugin
Plugin URI: https://github.com/alexeevdemyankov/munexul
Description: Creates an multidomain content filter SEO locations on your website.
Version: 1.9.0
Author: Ilya Alexeev
Author URI:  https://github.com/alexeevdemyankov
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/


/**
 * include munexul class
 */
include(plugin_dir_path(__FILE__) . 'includes/munexul.php');


/**
 * disable plugin in admin
 */

if (is_admin()) {
    ini_set('memory_limit', '512M');
    set_time_limit(800);
    /**
     * include install and admin class
     */
    include(plugin_dir_path(__FILE__) . 'includes/munexulinstall.php');
    include(plugin_dir_path(__FILE__) . 'includes/munexuladmin.php');
}
/**
 * include admin page
 */
include(plugin_dir_path(__FILE__) . 'includes/admin.php');

/**
 * install and unistall
 */

register_activation_hook(__FILE__, 'create_plugin_tables');
function create_plugin_tables()
{
    MunexulInstall::install();
}

register_uninstall_hook(__FILE__, 'drop_plugin_tables');
function drop_plugin_tables()
{
    MunexulInstall::uninstall();
}

/**
 * main functions
 */


if (!is_admin()) {

    /**
     * Buffers
     */
    add_action('wp_loaded', 'buffer_start');
    function buffer_start()
    {
        ob_start("munexul_callback");
    }

    function munexul_callback($buffer)
    {
        return Munexul::dataFilter($buffer);
    }


    add_action('shutdown', 'buffer_end');
    function buffer_end()
    {
        ob_end_flush();
    }

    /**
     * Filters static
     */

    /**
     * title parts
     */
    add_filter('document_title_parts', 'munexul_filter', 500);
    /**
     * main content
     */
    add_filter('the_content', 'munexul_filter', 500);
    /**
     * headers
     */
    add_filter('wp_headers', 'munexul_filter', 500);
    /**
     * parts of content
     */


    add_filter('the_excerpt', 'munexul_filter', 500);
    function munexul_filter($data)
    {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = Munexul::dataFilter($value);
            }
        } else {
            $data = Munexul::dataFilter($data);
        }
        return $data;
    }




    /**
     * All in One SEO
     */

    /**
     * keywords
     */
    add_action('aioseop_keywords', 'aio_meta_keywords', 500);

    function aio_meta_keywords($keywords)
    {

        $before = Munexul::getContentById(19, true);
        $after = Munexul::getContentById(20, true);
        if ($before):$before = $before . " ";endif;
        if ($after):$after = " " . $after;endif;
        $return = $before . $keywords . $after;
        $return = preg_replace('|[\s]+|s', ' ', $return);
        return trim($return);
    }

    /*
     * description
     */
    add_action('aioseop_description', 'aio_meta_description', 500);

    function aio_meta_description($description)
    {

        $before = Munexul::getContentById(21, true);
        $after = Munexul::getContentById(22, true);
        if ($before):$before = $before . " ";endif;
        if ($after):$after = " " . $after;endif;
        $return = $before . $description . $after;
        $return = preg_replace('|[\s]+|s', ' ', $return);
        return trim($return);
    }

    /**
     * title
     */
    add_action('aioseop_title', 'aio_meta_title', 500);

    function aio_meta_title($title)
    {
        $before = Munexul::getContentById(23, true);
        $after = Munexul::getContentById(24, true);
        if ($before):$before = $before . " ";endif;
        if ($after):$after = " " . $after;endif;
        $return = $before . $title . $after;
        $return = preg_replace('|[\s]+|s', ' ', $return);
        if ($config->title_orig_value) {
            $return = str_replace($config->title_orig_value, $config->title_replace_value, $return);
        }
        return trim($return);

    }


}






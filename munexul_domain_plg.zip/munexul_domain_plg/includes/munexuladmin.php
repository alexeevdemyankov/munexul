<?php

//Add xls support


(get_locale() == 'ru_RU')?include "langs/tagtypes_ru.php":include "langs/tagtypes_en.php";


class MunexulAdmin
{
    use tagTypes;



    //tags
    public static function insertTag($data)
    {
        if (self::validate($data, ['tag_code']) == 0):return null;endif;
        global $wpdb;
        $query = "
                        INSERT
                        INTO
                            " . $wpdb->prefix . "munexul_dplg_tags(tag_name,tag_type,tag_code)
                        VALUES
                            ('" . $data['tag_name'] . "','" . $data['tag_type'] . "','" . $data['tag_code'] . "')
                    ";
        $wpdb->query($query);
        return "<p class='update-message notice inline notice-warning notice-alt'>Тег добавлен " . Date('H:i:s') . "</p>";
    }

    public static function listTags()
    {
        global $wpdb;
        $query = "SELECT * FROM " . $wpdb->prefix . "munexul_dplg_tags";
        return $wpdb->get_results($query);
    }

    public static function getTag($id)
    {
        global $wpdb;
        $query = "SELECT * FROM " . $wpdb->prefix . "munexul_dplg_tags where id=" . $id;
        return $wpdb->get_results($query)[0];
    }

    public static function saveTag($data)
    {
        if ($data['action'] <> 'save'):return null;endif;
        global $wpdb;
        $query = "
                   UPDATE
                       " . $wpdb->prefix . "munexul_dplg_tags
                   SET
                        tag_name='" . $wpdb->escape($data['tag_name']) . "',
                        tag_code='" . $wpdb->escape($data['tag_code']) . "',
                        tag_type='" . $wpdb->escape($data['tag_type']) . "'                      
                   WHERE
                        id=" . $data['id'] . "
                    ";
        $wpdb->query($query);
        return "<p class='update-message notice inline notice-warning notice-alt'>Сохранено " . Date('H:i:s') . "</p>";

    }

    public static function deleteTag($data)
    {
        if ($data['action'] <> 'delete'):return null;endif;
        global $wpdb;
        $query = "
                        DELETE
                        FROM
                            " . $wpdb->prefix . "munexul_dplg_tags
                        WHERE
                            id=" . $data['id'] . "
                    ";
        $wpdb->query($query);
        return "
                            <div>
                            <p class='update-message notice inline notice-warning notice-alt'>Удалено, ожидайте</p>
                            </div>
                            <script type=\"text/javascript\">
                                location.replace(\"?page=munexul_domain_admin&plg_action=tag_list\");
                            </script>
                            ";
    }

    //end tags


    //domains

    public static function getDomains()
    {
        global $wpdb;
        $query = "SELECT * FROM " . $wpdb->prefix . "munexul_dplg";
        return $wpdb->get_results($query);
    }

    public static function insertDomain($data)
    {
        if (self::validate($data, ['domain_name']) == 0):return null;endif;
        global $wpdb;
        $query = "
                        INSERT
                        INTO
                            " . $wpdb->prefix . "munexul_dplg(domain,active)
                        VALUES
                            ('" . $data['domain_name'] . "','" . $data['domain_active'] . "')
                    ";
        $wpdb->query($query);
        return "<p class='update-message notice inline notice-warning notice-alt'>Сохранено " . Date('H:i:s') . "</p>";
    }

    public static function getDomain($id)
    {
        if (!$id):return null;endif;
        global $wpdb;
        $query = " SELECT * FROM " . $wpdb->prefix . "munexul_dplg WHERE id=$id";
        return $wpdb->get_results($query)[0];
    }

    public static function saveDomain($data)
    {
        if ($data['action'] <> 'save'):return null;endif;
        global $wpdb;
        $query = "
                        UPDATE
                            " . $wpdb->prefix . "munexul_dplg
                        SET
                            domain='" . $data['domain'] . "',
                            active='" . $data['active'] . "'
                        WHERE
                            id=" . $data['id'] . "
                    ";
        $wpdb->query($query);
        return "<p class='update-message notice inline notice-warning notice-alt'>Сохранено " . Date('H:i:s') . "</p>";
    }

    public static function deleteDomain($data)
    {
        if ($data['action'] <> 'delete'):return null;endif;
        global $wpdb;
        $query = "
                        DELETE
                        FROM
                            " . $wpdb->prefix . "munexul_dplg
                        WHERE
                            id=" . $data['id'] . "
                    ";
        $wpdb->query($query);
        return "
                            <div>
                            <p class='update-message notice inline notice-warning notice-alt'>Удалено, ожидайте</p>
                            </div>
                            <script type=\"text/javascript\">
                                location.replace(\"?page=munexul_domain_admin&plg_action=domain_list\");
                            </script>
                            ";
    }

    //end domains


    //content

    public static function saveContent($data)
    {
        if ($data['action'] <> 'save'):return null;endif;
        global $wpdb;
        foreach ($data['tag_value'] as $tag_id => $content_data) {
            $query = "select id from  " . $wpdb->prefix . "munexul_dplg_content where domain_id=" . $data['id'] . " and tag_id=" . $tag_id;
            $recordId = $wpdb->get_results($query)[0]->id;
            if ($recordId > 0) {
                $query = "
                        UPDATE  
                            " . $wpdb->prefix . "munexul_dplg_content 
                        SET
                            content_data='" . $wpdb->escape($content_data) . "'
                        WHERE 
                           id=" . $recordId . "    
                            ";

            } else {
                $query = "INSERT INTO " . $wpdb->prefix . "munexul_dplg_content(domain_id,tag_id ,content_data)
                VALUES(" . $data['id'] . "," . $tag_id . ",'" . $wpdb->escape($content_data) . "') 
                    ";
            }
            $wpdb->query($query);
        }
        return "<p class='update-message notice inline notice-warning notice-alt'>Сохранено " . Date('H:i:s') . "</p>";
    }

    public static function getContent($id)
    {
        global $wpdb;
        $query = "SELECT * FROM " . $wpdb->prefix . "munexul_dplg_content where domain_id=" . $id;
        $items = $wpdb->get_results($query);
        foreach ($items as $item) {
            $return[$item->tag_id] = $item->content_data;
        }
        return $return;

    }


    private static function validate($data, $needleArray)
    {
        foreach ($needleArray as $needleItem) {
            if (strlen($data[$needleItem]) == 0):return 0;endif;
        }
        return 1;
    }

    public static function tagType($id)
    {
        return self::$tagTypes[$id];
    }

    public static function tagOptions($default)
    {
        $return = '';
        foreach (self::$tagTypes as $tagId => $tagType) {
            $selected = ($default == $tagId) ? 'selected' : '';
            $return .= '<option value = "' . $tagId . '" ' . $selected . '>' . $tagType . '</option >';
        }
        return $return;
    }


    public static function input($name, $type, $value)
    {
        /* 1 => 'Текст',
         2 => 'Наценка на товар в %',
         3 => 'Фиксированая наценка',
         4 => 'HTML редактор'];*/
        $inputTextArray=[5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36];

        if(in_array($type,$inputTextArray)):$type=1;endif;

        switch ($type) {
            case 1:
                echo '<input name="' . $name . '" type="text" value="' . $value . '">';
                break;
            case 2:
                echo '<input name="' . $name . '" type="text" value="' . $value . '">';
                break;
            case 3:
                echo '<input name="' . $name . '" type="text" value="' . $value . '">';
                break;
            case 4:
                wp_editor($value, 'wpeditor', array('textarea_name' => $name));
                break;

        }


    }

    /*import-export*/


    public static function getImportContent($data, $file)
    {
        if ($data['action'] <> 'import'):return null;endif;
        $inputFileType = 'Xlsx';
        $inputFile = $file['import_file']['tmp_name'];
        if (is_file($inputFile)) {
            $return = new stdClass();
            $reader = IOFactory::createReader($inputFileType);
            $spreadsheet = $reader->load($inputFile);
            $sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);

            //Read tags
            foreach ($sheetData as $rowNum => $rowItem) {
                if ($rowNum == 1) {
                    $i = 0; //skip domain
                    foreach ($rowItem as $item) {
                        if ($i > 0):$return->tagArray[$i]->tag = trim($item);endif;
                        $i++;
                    }
                }
                //Read types
                if ($rowNum == 2) {
                    $i = 0; //skip domain
                    foreach ($rowItem as $item) {
                        if ($i > 0):$return->tagArray[$i]->type = $item;endif;
                        $i++;
                    }
                }

                //Read names
                if ($rowNum == 3) {
                    $i = 0; //skip domain
                    foreach ($rowItem as $item) {
                        if ($i > 0):$return->tagArray[$i]->name = $item;endif;
                        $i++;
                    }
                }

                //read data
                if ($rowNum > 3) {
                    $i = 0; //skip domain
                    foreach ($rowItem as $item) {
                        if ($i == 0) {
                            $return->domainArray[$rowNum - 3] = $item;
                        }
                        if ($i > 0):$return->varsArray[$rowNum - 3][$i]->value = $item;endif;
                        $i++;
                    }
                }
            }

            return $return;
        }
    }



    public static function getExportContent($data)
    {


        if ($data['action'] <> 'export'):return null;endif;
        $return = new stdClass();

        global $wpdb;

        $query = "select * from " . $wpdb->prefix . "munexul_dplg_content";
        $contentItems = $wpdb->get_results($query);
        foreach ($contentItems as $contentItem) {
            $return->contentData[$contentItem->domain_id][$contentItem->tag_id]->value = $contentItem->content_data;
        }

        $query = "select * from  " . $wpdb->prefix . "munexul_dplg_tags";
        $tagItems = $wpdb->get_results($query);
        foreach ($tagItems as $tagItem) {
            $return->tagData[$tagItem->id]->name = $tagItem->tag_name;
            $return->tagData[$tagItem->id]->type = $tagItem->tag_type;
            $return->tagData[$tagItem->id]->code = $tagItem->tag_code;
        }

        $query = "select * from  " . $wpdb->prefix . "munexul_dplg";
        $domainItems = $wpdb->get_results($query);
        foreach ($domainItems as $domainItem) {
            $return->domainData[$domainItem->id] = $domainItem->domain;
        }

        return $return;
    }


    private static function backupAndClear()
    {
        global $wpdb;

        $query = " set foreign_key_checks=0;";
        $wpdb->query($query);

        $query = "TRUNCATE " . $wpdb->prefix . "munexul_dplg_content";
        $wpdb->query($query);

        $query = "TRUNCATE TABLE " . $wpdb->prefix . "munexul_dplg_tags";
        $wpdb->query($query);

        $query = "TRUNCATE TABLE " . $wpdb->prefix . "munexul_dplg";
        $wpdb->query($query);

        $query = "set foreign_key_checks=1;";
        $wpdb->query($query);
    }


    public function pre($data)
    {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    }


}
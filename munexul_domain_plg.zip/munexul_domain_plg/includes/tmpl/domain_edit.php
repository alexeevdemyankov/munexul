<?php
include('header.php');
?>
<div class="postbox">
    <div class="inside">
        <h3><?=mLang::$btnEdit.' '.mb_strtolower(mLang::$labelDomain);?>  "<?= $items->domain; ?>"</h3>
        <form method="post">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $items->id; ?>">
            <?=mLang::$labelDomain;?>: <input type="text" name="domain" value="<?= $items->domain; ?>">
            <?=mLang::$labelActive;?>: <input type="checkbox" name="active" value="1" <?= ($items->active == 1) ? 'checked' : ''; ?>>
            <input type="submit" value="<?=mLang::$btnSave;?>">
        </form>
        <hr>
        <form method="post">
            <input type="hidden" name="id" value="<?= $items->id; ?>">
            <?=mLang::$labelConfirm;?> <input type="checkbox" name="action" value="delete">
            <input type="submit" value=" <?=mLang::$btnDel;?>">
        </form>
        <?php echo ($result_save) ? $result_save : ''; ?>
        <?php echo ($result_delete) ? $result_delete : ''; ?>
    </div>
</div>






<div>
    <h1><?= mLang::$title; ?>v.<?= Munexul::$version; ?></h1>
    <p class="about-text">
        <?= mLang::$description; ?>
    </p>
    <div class="tablenav top">
        <a class="button action"
           href="?page=munexul_domain_admin&plg_action=domain_list"><?= mLang::$btnMyDomain; ?></a>
        <a class="button action" href="?page=munexul_domain_admin&plg_action=tag_list"><?= mLang::$btnMyTags; ?></a>
        <a class="button action"
           href="?page=munexul_domain_admin&plg_action=import_export"><?= mLang::$btnImportExport; ?></a>
        <a class="button action" href="?page=munexul_domain_admin&plg_action=tag_types"><?= mLang::$btnTagTypes; ?></a>
        <?php if (is_plugin_active('advanced-custom-fields/acf.php')) { ?>
            <a class="button action" href="?page=munexul_domain_admin&plg_action=afs_config">
                <?= mLang::$btnADFConf; ?>
            </a>
        <?php } ?>
        <a class="button action"
           href="?page=munexul_domain_admin&plg_action=replace_config"><?= mLang::$btnReplaceConf; ?></a>
        <a class="button action" href="?page=munexul_domain_admin&plg_action=options"><?= mLang::$btnOptions; ?></a>
        <a class="button action" href="?page=munexul_domain_admin&plg_action=help"><?= mLang::$btnHelp; ?></a>
    </div>
</div>
<br>
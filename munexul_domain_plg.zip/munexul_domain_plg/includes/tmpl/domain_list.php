<?php include('header.php'); ?>
<div class="postbox">
    <div class="inside">
        <h3><?= mLang::$domainTitle; ?></h3>
        <p>
        <form method="post">
            <input type="hidden" name="domain_action" value="create">
            <?= mLang::$labelDomainName; ?> <input type="text" name="domain_name">
            <?= mLang::$labelActive; ?> <input type="checkbox" name="domain_active" value="1">
            <input class="button" type="submit" value="<?= mLang::$btnCreate; ?>">
        </form>
        <?php echo ($result_create) ? $result_create : ''; ?>
        </p>
        <table class="wp-list-table widefat fixed striped ">
            <tr>
                <th>#</th>
                <th><?= mLang::$labelDomain; ?></th>
                <th><?= mLang::$labelActive; ?></th>
                <th><?= mLang::$labelAction; ?></th>
                <th><?= mLang::$labelContent; ?></th>
            </tr>
            <?php foreach ($items as $item) { ?>
                <tr>
                    <td><?= $item->id; ?></td>
                    <td><?= $item->domain; ?></td>
                    <td><?= ($item->active == 1) ? mLang::$labelYes : mLang::$labelNo; ?></td>
                    <td>
                        <a href="?page=munexul_domain_admin&plg_action=domain_edit&id=<?= $item->id; ?>">
                            <?= mLang::$btnEdit; ?>
                        </a>
                    </td>
                    <td>
                        <a href="?page=munexul_domain_admin&plg_action=content_list&id=<?= $item->id; ?>">
                            <?= mLang::$btnEdit; ?>
                        </a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
</div>

<?php
include('header.php');
if ($_POST['munexul_root_category']) {
    echo "update!";
    $updatedFlag = update_option('munexul_root_category', $_POST['munexul_root_category'], $autoloadFlag);

}


?>

<div class="postbox">
    <div class="inside">
        <h3>Настройки главной страницы</h3>
        <form method="post" action="admin.php?page=munexul_domain_admin&plg_action=root_config">
            <?php settings_fields('munexul_root_category-settings'); ?>
            <?php do_settings_sections('munexul_root_category-settings'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">H1 woocommerce категории:</th>
                    <td><input type="text" name="munexul_root_category"
                               value="<?php echo get_option('munexul_root_category'); ?>"/>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
</div>

<?php
include('header.php');
if ($_POST) {
    $data = json_encode($_POST);
    $updatedFlag = update_option('munexul_options', $data, $autoloadFlag);
}
$options = json_decode(get_option('munexul_options'), true);
?>
<div class="postbox">
    <div class="inside">
        <p style="color:red;"><?=mLang::$onlyPro;?></p>
        <h3><?= mLang::$btnOptions; ?></h3>
        <form method="post" action="admin.php?page=munexul_domain_admin&plg_action=options">
            <?php settings_fields('munexul_options-settings'); ?>
            <?php do_settings_sections('munexul_options-settings'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?= mLang::$labelH1toKwords; ?></th>
                    <td><input type="checkbox" name="munexul_h1_keywords"
                               value="1"
                            <?= ($options['munexul_h1_keywords'] == 1) ? "checked" : ""; ?>/>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
</div>

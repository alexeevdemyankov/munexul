<?php
include('header.php');
?>
<div class="postbox">
    <div class="inside">
        <h3><?=mLang::$btnEdit.' '.mb_strtolower(mLang::$labelTag);?> "<?= $items->tag_name; ?>"</h3>
        <form method="post">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $items->id; ?>">
            <?=mLang::$labelTag;?>: <input type="text" name="tag_name" value="<?= $items->tag_name; ?>">
            <?=mLang::$labelCode;?>: <input type="text" name="tag_code" value="<?= $items->tag_code; ?>">
            <?=mLang::$labelType;?> <select name="tag_type"><?= MunexulAdmin::tagOptions($items->tag_type); ?></select>
            <input type="submit" value="<?=mLang::$btnSave;?>">
        </form>
        <hr>
        <form method="post">
            <input type="hidden" name="id" value="<?= $items->id; ?>">
            <?=mLang::$labelConfirm;?> <input type="checkbox" name="action" value="delete">
            <input type="submit" value="<?=mLang::$btnDel;?>">
        </form>
        <?php echo ($result_save) ? $result_save : ''; ?>
        <?php echo ($result_delete) ? $result_delete : ''; ?>
    </div>
</div>







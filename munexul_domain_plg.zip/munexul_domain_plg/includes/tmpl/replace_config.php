<?php
include('header.php');
if ($_POST) {
    $postData = json_encode($_POST);
    $updatedFlag = update_option('munexul_replace', $postData, $autoloadFlag);
}
$config = json_decode(get_option('munexul_replace'));
?>

<div class="postbox">
    <div class="inside">
        <p style="color:red;"><?=mLang::$onlyPro;?></p>
        <h3><?=mLang::$btnReplaceConf;?></h3>
        <i><?=mLang::$replaceDescription;?></i>
        <form method="post" action="admin.php?page=munexul_domain_admin&plg_action=replace_config">
            <?php settings_fields('munexul_replace-settings'); ?>
            <?php do_settings_sections('munexul_replace-settings'); ?>
            <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?=mLang::$labelAllTitles;?>:</th>
                        <td><?=mLang::$labelFrom;?> <input type="text" name="title_orig_value"
                                   value="<?=$config->title_orig_value;?>"/>
                        </td>
                        <td><?=mLang::$labelTo;?>  <input type="text" name="title_replace_value"
                                   value="<?=$config->title_replace_value;?>"/>
                        </td>
                    </tr>
                <tr valign="top">
                    <th scope="row"><?=mLang::$labelCatTitles;?>:</th>
                    <td><?=mLang::$labelFrom;?> <input type="text" name="title_cat_orig_value"
                                 value="<?=$config->title_cat_orig_value;?>"/>
                    </td>
                    <td><?=mLang::$labelTo;?> <input type="text" name="title_cat_replace_value"
                                  value="<?=$config->title_cat_replace_value;?>"/>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?=mLang::$labelProdTitles;?>:</th>
                    <td><?=mLang::$labelFrom;?> <input type="text" name="title_prod_orig_value"
                                 value="<?=$config->title_prod_orig_value;?>"/>
                    </td>
                    <td><?=mLang::$labelTo;?> <input type="text" name="title_prod_replace_value"
                                  value="<?=$config->title_prod_replace_value;?>"/>
                    </td>
                </tr>

            </table>
            <?php submit_button(); ?>
        </form>
    </div>
</div>


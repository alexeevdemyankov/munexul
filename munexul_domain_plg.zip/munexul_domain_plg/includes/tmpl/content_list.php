<?php
include('header.php');
?>
<div class="postbox">
    <div class="inside">
        <h3>
            <?= mLang::$btnEdit . ' ' . mb_strtolower(mLang::$labelContent) . ' ' . mb_strtolower(mLang::$labelDomainR); ?>
            "<?= $domain->domain; ?>"
        </h3>
        <form method="post">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $domain->id; ?>">
            <table class="table">
                <?php foreach ($tags as $tag) { ?>
                    <tr>
                        <td> <?= $tag->tag_name; ?></td>
                        <td> <?php MunexulAdmin::input('tag_value[' . $tag->id . ']', $tag->tag_type, $items[$tag->id]); ?>
                        </td>
                    </tr>
                <? } ?>
            </table>
            <input type="submit" class="button" value="<?=mLang::$btnSave;?>">
        </form>
    </div>
</div>


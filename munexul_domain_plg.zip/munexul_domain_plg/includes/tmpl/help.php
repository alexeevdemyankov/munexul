<?php
include('header.php');
?>
<div class="postbox">
    <div class="inside">
        <h3><?=mLang::$btnHelp;?></h3>
        <p style="color:red;"><?=mLang::$full;?></p>
        <?php $patch=str_replace('tmpl/','',plugin_dir_path(__FILE__ ));?>
        <?(get_locale() == 'ru_RU') ? include($patch.'/langs/help_ru.php') : include($patch.'/langs/help_en.php');?>
    </div>
</div>


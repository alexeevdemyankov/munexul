<?php
include('header.php');

echo get_locale();

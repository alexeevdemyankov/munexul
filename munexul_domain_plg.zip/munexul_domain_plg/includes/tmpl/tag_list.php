<?php
include('header.php');
?>
<div class="postbox">
    <div class="inside">
        <h3><?=mLang::$tagListTitle;?></h3>
        <p>
        <form method="post">
            <input type="hidden" name="action" value="insert">
            <?=mLang::$labelTag;?>
            <input type="text" name="tag_name" placeholder="Новый тег">
            <?=mLang::$labelCode;?>
            <input type="text" name="tag_code" value="[%tag%]">
            <?=mLang::$labelType;?>
            <select name="tag_type">
                <?= MunexulAdmin::tagOptions(1); ?>
            </select>
            <input type="submit" class="button" value="<?=mLang::$btnCreate;?>">
        </form>
        <?php echo ($result_create) ? $result_create : ''; ?>
        </p>
        <table class="wp-list-table widefat fixed striped ">
            <tr>
                <th>#</th>
                <th><?=mLang::$labelTag;?></th>
                <th><?=mLang::$labelType;?></th>
                <th><?=mLang::$labelCode;?></th>
                <th><?=mLang::$btnEdit;?></th>
            </tr>
            <?php foreach ($items as $item) { ?>
                <tr>
                    <td><?= $item->id; ?></td>
                    <td><?= $item->tag_name; ?></td>
                    <td><?= MunexulAdmin::tagType($item->tag_type); ?></td>
                    <td><?= $item->tag_code; ?></td>
                    <td>  <a href="?page=munexul_domain_admin&plg_action=tag_edit&id=<?= $item->id; ?>"><?=mLang::$btnEdit;?></a></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</div>

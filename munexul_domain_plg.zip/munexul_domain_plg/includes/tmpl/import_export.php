<?php
include('header.php');
?>
<p style="color:red;"><?=mLang::$onlyPro;?></p>
<div class="postbox">
    <div class="inside">
        <h3><?=mLang::$labelImport;?></h3>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="import">
            <?=mLang::$labelFile;?> XLSX: <input type="file" name="import_file">
            <input type="submit" value="<?=mLang::$btnExec;?>">
        </form>
        <?php echo ($result_import) ? $result_import : ''; ?>
    </div>
</div>

<div class="postbox">
    <div class="inside">
        <h3><?=mLang::$labelExport;?></h3>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="export">
            <input type="submit" value="<?=mLang::$btnExec;?>">
        </form>
        <?php echo ($result_export) ? $result_export : ''; ?>
    </div>
</div>

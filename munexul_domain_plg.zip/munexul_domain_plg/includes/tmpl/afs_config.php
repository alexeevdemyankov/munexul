<?php
include('header.php');
if ($_POST['munexul_alter_category']) {
    $updatedFlag = update_option('munexul_alter_category', $_POST['munexul_alter_category'], $autoloadFlag);
}
?>
<div class="postbox">
    <div class="inside">
        <p style="color:red;"><?=mLang::$onlyPro;?></p>
        <h3><?=mLang::$btnADFConf;?></h3>
        <i><?=mLang::$adfDescription;?></i>
        <form method="post" action="admin.php?page=munexul_domain_admin&plg_action=afs_config">
            <?php settings_fields('munexul_alter_category-settings'); ?>
            <?php do_settings_sections('munexul_alter_category-settings'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?=mLang::$adfFieldName;?>:</th>
                    <td><input type="text" name="munexul_alter_category"
                               value="<?php echo get_option('munexul_alter_category'); ?>"/>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
</div>


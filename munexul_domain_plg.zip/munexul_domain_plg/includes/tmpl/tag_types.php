<?php
include('header.php');
?>
<div class="postbox">
    <div class="inside">
        <h3><?=mLang::$btnTagTypes;?></h3>
        <table class="wp-list-table widefat fixed striped ">
            <tr>
                <th>#</th>
                <th><?=mLang::$labelType;?></th>
            </tr>
            <?php foreach (MunexulAdmin::$tagTypes as $id => $type) { ?>
                <tr>
                    <td><?= $id; ?></td>
                    <td><?= $type; ?></td>
                </tr>
            <? } ?>
        </table>
    </div>
</div>
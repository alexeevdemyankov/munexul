<?php
(get_locale() == 'ru_RU') ? include('langs/ru.php') : include('langs/en.php');

add_action('admin_menu', 'menu_munexul_domain_plg');

function menu_munexul_domain_plg()
{
    add_menu_page('Munexul domain Plugin', 'Munexul domain Plugin', 'manage_options', 'munexul_domain_admin', 'admin_list', 'dashicons-admin-site-alt3', 1);
}


function admin_list()
{
    $tpl = $_GET['plg_action'];
    switch ($tpl) {
        case '':
            $tpl = 'default';
            break;
        case 'tag_list':
            $result_create = MunexulAdmin::insertTag($_POST);
            $items = MunexulAdmin::listTags();
            break;
        case 'tag_edit':
            $result_save = MunexulAdmin::saveTag($_POST);
            $result_delete = MunexulAdmin::deleteTag($_POST);
            $items = MunexulAdmin::getTag($_GET['id']);
            break;
        case 'domain_list':
            $result_create = MunexulAdmin::insertDomain($_POST);
            $items = MunexulAdmin::getDomains();
            break;
        case 'domain_edit':
            $result_save = MunexulAdmin::saveDomain($_POST);
            $result_delete = MunexulAdmin::deleteDomain($_POST);
            $items = MunexulAdmin::getDomain($_GET['id']);
            break;
        case 'content_list':
            $result_save = MunexulAdmin::saveContent($_POST);
            $tags = MunexulAdmin::listTags();
            $domain = MunexulAdmin::getDomain($_GET['id']);
            $items = MunexulAdmin::getContent($_GET['id']);
            break;
    }
    if (!is_file(__DIR__ . '/tmpl/' . $tpl . '.php')):$tpl = 'error';endif;
    include('tmpl/' . $tpl . '.php');

}
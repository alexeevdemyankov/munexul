<?php

class Munexul
{

    public static $version = '1.9.1 FREE';

    private static $replaceArray = null;


    /*filter*/
    public static function dataFilter($content)
    {
        if (self::$replaceArray == null):self::getReplaceArray();endif;
        foreach (self::$replaceArray as $tag => $value) {
            $content = str_replace($tag, $value, $content);
        }
        return $content;
    }

    public static function listTags()
    {
        global $wpdb;
        $query = "SELECT * FROM " . $wpdb->prefix . "munexul_dplg_tags";
        $result = $wpdb->get_results($query);
        return $result;
    }

    public static function getReplaceArray()
    {
        $items = self::getContentById(0, false);
        foreach ($items as $item) {
            self::$replaceArray[$item->tag_code] = $item->content_data;
        }
        $allTags = self::listTags();
        foreach ($allTags as $tag) {
            if (!self::$replaceArray[$tag->tag_code]): self::$replaceArray[$tag->tag_code] = '';endif;
        }


    }

    /*category*/
    public static function getBeforeCategoryH1()
    {
        return self::getContentById(15, true);
    }

    public static function getAfterCategoryH1()
    {
        return self::getContentById(16, true);
    }


    /*product*/

    public static function getBeforeProductH1()
    {
        return self::getContentById(17, true);
    }

    public static function getAfterProductH1()
    {
        return self::getContentById(18, true);
    }

    public static function getBeforeDescProduct()
    {
        return self::getContentById(13, true);
    }

    public static function getAfterDescProduct()
    {
        return self::getContentById(14, true);
    }

    public static function getBeforeTitleProduct()
    {
        return self::getContentById(11, true);
    }

    public static function getAfterTitleProduct()
    {
        return self::getContentById(12, true);
    }

    /*category*/
    public static function getBeforeDescCategory()
    {
        return self::getContentById(9, true);
    }

    public static function getAfterDescCategory()
    {
        return self::getContentById(10, true);
    }

    public static function getBeforeTitleCategory()
    {
        return self::getContentById(7, true);
    }

    public static function getAfterTitleCategory()
    {
        return self::getContentById(8, true);
    }

    /*price*/
    public static function getWooPricePercent()
    {
        return self::getContentById(2, true);
    }

    public static function getWooPriceAdd()
    {
        return self::getContentById(3, true);
    }

    public static function getReplaceMail()
    {
        return self::getContentById(5, true);
    }

    public static function getReplaceMailName()
    {
        return self::getContentById(6, true);
    }

    /*getContent*/

    public static function getContentById($idString, $returnData)
    {
        global $wpdb;

        if ($idString > 0) {
            $and = " AND tg.tag_type in (" . $idString . ")";
        }

        $domain = str_replace('www.', '', $_SERVER['HTTP_HOST']);
        $query = "
            SELECT 
              tag_code,
              content_data
            FROM
                 " . $wpdb->prefix . "munexul_dplg as dm,
                 " . $wpdb->prefix . "munexul_dplg_content as dc,
                 " . $wpdb->prefix . "munexul_dplg_tags as tg
            WHERE
              tg.id=dc.tag_id 
            AND
              dm.domain like '" . $domain . "'
            AND
              dm.id=dc.domain_id               
            AND
              dm.active=1                                 
        " . $and;

        if ($returnData === true) {
            return $wpdb->get_results($query)[0]->content_data;
        } else {
            return $wpdb->get_results($query);
        }
    }


}
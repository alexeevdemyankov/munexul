<?php

class MunexulInstall
{

    public static function install()
    {

        global $wpdb;
        $installQuery = str_replace('wp_', $wpdb->prefix, self::$installQuery);
        $querys = explode(';', $installQuery);
        foreach ($querys as $query) {
            $wpdb->query($query);
        }
    }

    public static function uninstall()
    {
        global $wpdb;
        $querys[] = "DROP TABLE " . $wpdb->prefix . "munexul_dplg_content;";
        $querys[] = "DROP TABLE " . $wpdb->prefix . "munexul_dplg;";
        $querys[] = "DROP TABLE " . $wpdb->prefix . "munexul_dplg_tags;";
        foreach ($querys as $query) {
            $wpdb->query($query);
        }

    }

    private static $installQuery = "
    
CREATE TABLE `wp_munexul_dplg` (
  `id` int(11) NOT NULL,
  `domain` varchar(128) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `wp_munexul_dplg_content` (
  `id` int(11) NOT NULL,
  `domain_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `content_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `wp_munexul_dplg_tags` (
  `id` int(11) NOT NULL,
  `tag_name` varchar(255) NOT NULL,
  `tag_type` int(11) NOT NULL,
  `tag_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



ALTER TABLE `wp_munexul_dplg`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `domain` (`domain`);

ALTER TABLE `wp_munexul_dplg_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `domain_id` (`domain_id`),
  ADD KEY `tag_id` (`tag_id`);

ALTER TABLE `wp_munexul_dplg_tags`
  ADD PRIMARY KEY (`id`);
  
 
ALTER TABLE `wp_munexul_dplg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `wp_munexul_dplg_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `wp_munexul_dplg_tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `wp_munexul_dplg_content`
  ADD CONSTRAINT `wp_munexul_dplg_content_ibfk_1` FOREIGN KEY (`domain_id`) REFERENCES `wp_munexul_dplg` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `wp_munexul_dplg_content_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `wp_munexul_dplg_tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

    ";

}
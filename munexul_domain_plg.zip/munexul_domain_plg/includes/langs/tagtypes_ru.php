<?php

trait tagTypes{
    public static $tagTypes = [
        1 => 'Текст',
        2 => 'Наценка на товар в % Woocomerce(Только в Pro)',
        3 => 'Фиксированая наценка Woocomerce(Только в Pro)',
        4 => 'HTML редактор',
        5 => 'Системный email отправителя(Только в Pro)',
        6 => 'Системный Имя отправителя(Только в Pro)',
        //woocomerce
        7 => 'До заголовка категории Woocomerce(Только в Pro)',
        8 => 'После заголовка категории Woocomerce(Только в Pro)',
        9 => 'До описания категории Woocomerce(Только в Pro)',
        10 => 'После описания категории Woocomerce(Только в Pro)',
        11 => 'До заголовка товара Woocomerce(Только в Pro)',
        12 => 'После заголовка товара Woocomerce(Только в Pro)',
        13 => 'До описания товара Woocomerce(Только в Pro)',
        14 => 'После описания товара Woocomerce(Только в Pro)',
        15 => 'До H1 категории Woocomerce(Только в Pro)',
        16 => 'После H1 категории Woocomerce(Только в Pro)',

        17 => 'До H1 товара Woocomerce(Только в Pro)',
        18 => 'После H1 товара Woocomerce(Только в Pro)',
        //aio
        19 => 'aio до meta keywords страницы',
        20 => 'aio после meta keywords страницы',
        21 => 'aio до meta description страницы',
        22 => 'aio после meta description страницы',
        23 => 'aio до meta title страницы',
        24 => 'aio после meta title страницы',
        //aio woo
        25 => 'aio до meta keywords товара(Только в Pro)',
        26 => 'aio после meta keywords товара(Только в Pro)',
        27 => 'aio до meta description товара(Только в Pro)',
        28 => 'aio после meta description товара(Только в Pro)',
        29 => 'aio до meta title товара(Только в Pro)',
        30 => 'aio после meta title товара(Только в Pro)',
        //aio woo category
        31 => 'aio до meta keywords категории(Только в Pro)',
        32 => 'aio после meta keywords категории(Только в Pro)',
        33 => 'aio до meta description категории(Только в Pro)',
        34 => 'aio после meta description категории(Только в Pro)',
        35 => 'aio до meta title категории(Только в Pro)',
        36 => 'aio после meta title категории(Только в Pro)'


    ];
}
<?php

/**
 * Class mLang Russian Language
 */
class mLang
{
    public static $title = "Munexul Domain Plugin";
    public static $description = "Content filter for multidomain sites.";
    public static $btnMyDomain = "My domains";
    public static $btnMyTags = "My tags";
    public static $btnImportExport = "Import-Export";
    public static $btnTagTypes = "Tag types";
    public static $btnADFConf = "Settings of Advanced Custom Fields";
    public static $btnReplaceConf = "Settings of replace list";
    public static $btnOptions = "Options";
    public static $btnHelp = "Help";
    /*Buttons*/
    public static $btnCreate = "Create";
    public static $btnEdit = "Change";
    public static $btnSave = "Save";
    public static $btnDel = "Delete";
    public static $btnExec = "Execute";
    /*labels*/
    public static $labelActive = "Active";
    public static $labelDomain = "Domain";
    public static $labelDomainR = "of domain";
    public static $labelAction = "Action";
    public static $labelContent = "Content";
    public static $labelYes = "Yes";
    public static $labelNo = "No";
    public static $labelConfirm = "Confirm";
    /*domains*/
    public static $domainTitle = "Domain list";
    public static $labelDomainName = "Domain name";
    /*tags*/
    public static $tagListTitle = "Tag list";
    public static $labelTag = "Tag";
    public static $labelCode = "Code";
    public static $labelType = "Type";
    /*import-export*/
    public static $labelImport = "Import";
    public static $labelExport = "Export";
    public static $labelFile = "File";
    /*ADF*/
    public static $adfDescription = "Enter name of field for category title ";
    public static $adfFieldName = "Field for category name";
    /*replace*/
    public static $replaceDescription = "Replace string data";
    public static $labelFrom = "from";
    public static $labelTo = "to";
    public static $labelAllTitles = "For all Titles";
    public static $labelCatTitles = "For Title of category";
    public static $labelProdTitles = "For Title of product";
    /*options*/
    public static $labelH1toKwords = "Add H1 to Keywords";
    public static $onlyPro = "Only Pro version";

    public static $full = "Full version avalible only with request to b333@bk.ru message  Munexul";

}
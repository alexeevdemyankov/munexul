<?php

trait tagTypes
{
    public static $tagTypes = [
        1 => 'Text',
        2 => 'Cost add percent % Woocomerce(Pro only)',
        3 => 'Fix cost add Woocomerce(Pro only)',
        4 => 'HTML editor',
        5 => 'System email sender(Pro only)',
        6 => 'System email sender name(Pro only)',
        //woocomerce
        7 => 'Before category title Woocomerce(Pro only)',
        8 => 'After category title Woocomerce(Pro only)',
        9 => 'Before category description Woocomerce(Pro only)',
        10 => 'After category description Woocomerce(Pro only)',
        11 => 'Before product title Woocomerce(Pro only)',
        12 => 'After product title Woocomerce(Pro only)',
        13 => 'Before product description Woocomerce(Pro only)',
        14 => 'After product description Woocomerce(Pro only)',
        15 => 'Before category H1 Woocomerce(Pro only)',
        16 => 'After categiry H1 Woocomerce(Pro only)',
        17 => 'Before product H1  Woocomerce(Pro only)',
        18 => 'After product H1  Woocomerce(Pro only)',
        //aio
        19 => 'aio before meta keywords page',
        20 => 'aio after meta keywords page',
        21 => 'aio before meta description page',
        22 => 'aio after meta description page',
        23 => 'aio before meta title page',
        24 => 'aio after meta title page',
        //aio woo
        25 => 'aio before meta keywords product(Pro only)',
        26 => 'aio after meta keywords product(Pro only)',
        27 => 'aio before meta description product(Pro only)',
        28 => 'aio after meta description product(Pro only)',
        29 => 'aio before meta title product(Pro only)',
        30 => 'aio after meta title product(Pro only)',
        //aio woo category
        31 => 'aio before meta keywords category(Pro only)',
        32 => 'aio after meta keywords category(Pro only)',
        33 => 'aio before meta description category(Pro only)',
        34 => 'aio after meta description category(Pro only)',
        35 => 'aio before meta title category(Pro only)',
        36 => 'aio after meta title category(Pro only)'


    ];
}
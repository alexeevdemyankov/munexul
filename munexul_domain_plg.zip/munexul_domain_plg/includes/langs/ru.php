<?php

/**
 * Class mLang Russian Language
 */
class mLang
{
    public static $title = "Munexul Domain Plugin";
    public static $description = "Плагин контент фильтр данных для управления мультидоменами.";
    public static $btnMyDomain = "Мои домены";
    public static $btnMyTags = "Мои теги";
    public static $btnImportExport = "Импорт-экспорт";
    public static $btnTagTypes = "Типы тегов";
    public static $btnADFConf = "Настроки Advanced Custom Fields";
    public static $btnReplaceConf = "Настроки листа подмен";
    public static $btnOptions = "Опции";
    public static $btnHelp = "Помощь";
    /*Buttons*/
    public static $btnCreate = "Создать";
    public static $btnEdit = "Изменить";
    public static $btnSave = "Сохранить";
    public static $btnDel = "Удалить";
    public static $btnExec = "Выполнить";
    /*labels*/
    public static $labelActive = "Активен";
    public static $labelDomain = "Домен";
    public static $labelDomainR = "Домена";
    public static $labelAction = "Действие";
    public static $labelContent = "Контент";
    public static $labelYes = "Да";
    public static $labelNo = "Нет";
    public static $labelConfirm = "Подтвердить";
    /*domains*/
    public static $domainTitle = "Список доменов";
    public static $labelDomainName = "Имя домена";
    /*tags*/
    public static $tagListTitle = "Список тегов";
    public static $labelTag = "Тег";
    public static $labelCode = "Код";
    public static $labelType = "Тип";
    /*import-export*/
    public static $labelImport = "Импорт";
    public static $labelExport = "Экспорт";
    public static $labelFile = "Файл";
    /*ADF*/
    public static $adfDescription = "Введите имя поля созданого для заголовка категории";
    public static $adfFieldName = "Поле заголовка категории";
    /*replace*/
    public static $replaceDescription = "Заменяет данные в строке";
    public static $labelFrom = "с";
    public static $labelTo = "на";
    public static $labelAllTitles = "Во всех Title";
    public static $labelCatTitles = "В Title категории";
    public static $labelProdTitles = "В Title продукта";
    /*options*/
    public static $labelH1toKwords = "H1 поместить в Keywords";

    /*types*/
    public static $tagTypeText = 'Текст';

    public static $onlyPro = "Только в Pro версии";
    public static $full = "Полная версия доступна по запросу b333@bk.ru с пометкой Munexul";




}
<p>
     You can use plugin for subdomains or multydomain sites
<ul>
    <li>site.ru</li>
    <li>moskva.site.ru</li>
    <li>spb.site.ru</li>
    <li>vladivostok.site.ru</li>
</ul>
you can change data for each domai, shop data and SEO.
</p>


<p>1.For using pleace create tags-holders. Put it into text. All holders will be replaced with domain string.
   For example, pleace create in Tags:
<ul>
    <li>City [%city%] type Text</li>
    <li>Phone [%phone%] type Text</li>
</ul>
<p>
    2. Create master domain and sub domains - and fill all content fields.
</p>
<p>
    3. Use in your texts tags [%city%] - for example - Iám live in [%city%];
</p>
<p>
    Done!
</p>
<p>
    * for using with subdomains pleace add into wp-config.php after database config
    chose and replace protocol http/https.
<ul>
    <li>define('WP_HOME', 'http://' . $_SERVER['HTTP_HOST'] );</li>
    <li>define('WP_SITEURL', 'http://' . $_SERVER['HTTP_HOST'] );</li>
</ul>


</p>
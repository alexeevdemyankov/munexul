=== Munexul multi domain plugin ===
Contributors: Alexeev Ilya
Tags: Domain, SEO, Tags, Holders
Requires at least: 5.1
Tested up to: 5.5
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
This multy domain plugin for subregional sites. Plugin based on holders in text , replace and modify  meta data.